# Time Counter — Version 1

This is the first mobile-friendly prototype of Time Counter.

## Included
- English/Russian language switch
- Clock in and clock out
- Automatic elapsed shift time
- Daily and monthly totals
- Attendance history
- CSV export
- Local browser storage
- Basic PWA/offline support

## Important limitation
This first prototype stores attendance on the device/browser where it is used. It does NOT yet provide shared employee accounts, restaurant codes, manager access, or server-side verified timestamps. Do not use it as an official payroll record yet.

## Put it online from your Android phone
1. Create or sign in to a GitHub account at https://github.com
2. Create a new public repository named `time-counter`.
3. Upload `index.html`, `manifest.webmanifest`, and `sw.js` from this folder.
4. In the repository, open Settings → Pages.
5. Under Build and deployment, choose Deploy from a branch, select `main` and `/ (root)`, then Save.
6. Wait for GitHub Pages to publish the site. Open the published HTTPS address in Chrome on Android.
7. In Chrome, open the menu (⋮) and choose Install app or Add to Home screen.

## Next version
Connect Supabase for secure sign-in, restaurant join codes, manager/staff roles, shared attendance records, server timestamps, and audit history. After the hosted PWA works, it can be packaged as an Android APK using a PWA-to-APK workflow. A native APK is not included in this ZIP.
